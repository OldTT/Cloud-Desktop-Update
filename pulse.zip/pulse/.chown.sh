######检测到用户为root则修改属主
YONGHU1=`whoami`
if [ "$YONGHU1" = "root" ];then
                chown root:root /home/headless/
fi
