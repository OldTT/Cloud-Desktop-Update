#!/bin/bash
while true;do
count=`ps -ef|grep ffmpeg|grep -v grep 2> /dev/null`
if [ "$?" -ne  "0" ];then
        ps -ef|grep vncproxy|grep -v grep 2> /dev/null
        if [ "$?" ==  "0" ];then
                pulseaudio -k
                pulseaudio -D
                sleep 0.5
                ffmpeg -y -nostdin -f alsa -i pulse  -f mpegts  -codec:a mp2 udp://localhost:1234 > ~/pulse/.log/vnc-audio.log 2>&1 &
		bash /home/headless/pulse/.chown.sh
        fi
else
        break
fi
sleep 3
done
